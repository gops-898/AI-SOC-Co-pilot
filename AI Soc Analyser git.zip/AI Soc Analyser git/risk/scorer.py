"""
Risk Scorer Module
Calculate risk scores based on detected threats and IOCs
Evidence-based scoring to prevent hallucination
"""


class RiskScorer:
    """Calculate security risk score based on evidence."""
    
    # Severity weight mapping
    SEVERITY_WEIGHTS = {
        "CRITICAL": 40,
        "HIGH": 25,
        "MEDIUM": 10,
        "LOW": 3
    }
    
    # IOC type weights
    IOC_WEIGHTS = {
        "malicious_ip": 20,
        "malicious_domain": 15,
        "malicious_url": 15,
        "malicious_hash": 25,
        "suspicious_email": 5,
        "suspicious_keyword": 2
    }
    
    def calculate_risk(self, findings, iocs):
        """
        Calculate risk score based on actual evidence.
        
        Args:
            findings (list): List of detected threats
            iocs (dict): Extracted indicators of compromise
        
        Returns:
            dict: Risk assessment with score and level
        """
        
        score = 0
        evidence_count = 0
        
        # Score from findings
        if findings:
            for finding in findings:
                severity = finding.get("severity", "MEDIUM")
                weight = self.SEVERITY_WEIGHTS.get(severity, 5)
                score += weight
                evidence_count += 1
        
        # Score from IOCs
        ioc_score, ioc_count = self._score_iocs(iocs)
        score += ioc_score
        evidence_count += ioc_count
        
        # Cap score at 100
        final_score = min(score, 100)
        
        # Determine risk level
        risk_level = self._get_risk_level(final_score, evidence_count)
        
        return {
            "score": final_score,
            "level": risk_level,
            "evidence_count": evidence_count,
            "details": self._get_risk_details(findings, iocs)
        }
    
    def _score_iocs(self, iocs):
        """
        Score IOCs based on type and count.
        
        Args:
            iocs (dict): Extracted IOCs
        
        Returns:
            tuple: (score, count) of IOCs
        """
        
        score = 0
        count = 0
        
        if not iocs or not isinstance(iocs, dict):
            return score, count
        
        # Score IPs
        ipv4_list = iocs.get("ips", {}).get("ipv4", [])
        score += len(ipv4_list) * self.IOC_WEIGHTS["malicious_ip"]
        count += len(ipv4_list)
        
        # Score domains
        domain_list = iocs.get("domains", [])
        score += len(domain_list) * self.IOC_WEIGHTS["malicious_domain"]
        count += len(domain_list)
        
        # Score URLs
        url_list = iocs.get("urls", [])
        score += len(url_list) * self.IOC_WEIGHTS["malicious_url"]
        count += len(url_list)
        
        # Score hashes
        hash_count = (
            len(iocs.get("hashes", {}).get("md5", [])) +
            len(iocs.get("hashes", {}).get("sha1", [])) +
            len(iocs.get("hashes", {}).get("sha256", []))
        )
        score += hash_count * self.IOC_WEIGHTS["malicious_hash"]
        count += hash_count
        
        # Score emails
        email_list = iocs.get("emails", [])
        score += len(email_list) * self.IOC_WEIGHTS["suspicious_email"]
        count += len(email_list)
        
        # Score suspicious keywords
        keyword_list = iocs.get("suspicious_keywords", [])
        score += len(keyword_list) * self.IOC_WEIGHTS["suspicious_keyword"]
        count += len(keyword_list)
        
        return score, count
    
    def _get_risk_level(self, score, evidence_count):
        """
        Determine risk level based on score and evidence.
        
        Args:
            score (int): Risk score (0-100)
            evidence_count (int): Number of evidence items
        
        Returns:
            str: Risk level
        """
        
        # If no evidence, it's low risk
        if evidence_count == 0:
            return "LOW"
        
        # Score-based assessment
        if score >= 80:
            return "CRITICAL"
        elif score >= 60:
            return "HIGH"
        elif score >= 40:
            return "MEDIUM"
        elif score >= 20:
            return "MEDIUM-LOW"
        else:
            return "LOW"
    
    def _get_risk_details(self, findings, iocs):
        """
        Get detailed risk information.
        
        Args:
            findings (list): Detected threats
            iocs (dict): Extracted IOCs
        
        Returns:
            dict: Risk details
        """
        
        details = {
            "threat_count": len(findings) if findings else 0,
            "critical_threats": 0,
            "high_threats": 0,
            "ioc_count": self._count_iocs(iocs),
            "primary_concerns": []
        }
        
        # Count by severity
        for finding in findings:
            severity = finding.get("severity", "MEDIUM")
            if severity == "CRITICAL":
                details["critical_threats"] += 1
            elif severity == "HIGH":
                details["high_threats"] += 1
        
        # List primary concerns
        if details["critical_threats"] > 0:
            details["primary_concerns"].append(f"{details['critical_threats']} CRITICAL threat(s) detected")
        if details["high_threats"] > 0:
            details["primary_concerns"].append(f"{details['high_threats']} HIGH threat(s) detected")
        if details["ioc_count"] > 0:
            details["primary_concerns"].append(f"{details['ioc_count']} indicator(s) of compromise")
        
        if not details["primary_concerns"]:
            details["primary_concerns"].append("No significant threats detected")
        
        return details
    
    def _count_iocs(self, iocs):
        """Count total IOCs."""
        count = 0
        if not iocs:
            return count
        
        count += len(iocs.get("ips", {}).get("ipv4", []))
        count += len(iocs.get("ips", {}).get("ipv6", []))
        count += len(iocs.get("emails", []))
        count += len(iocs.get("urls", []))
        count += len(iocs.get("domains", []))
        count += len(iocs.get("hashes", {}).get("md5", []))
        count += len(iocs.get("hashes", {}).get("sha1", []))
        count += len(iocs.get("hashes", {}).get("sha256", []))
        
        return count


def calculate_risk(findings, iocs):
    """
    Convenience function to calculate risk.
    
    Args:
        findings (list): Detected threats
        iocs (dict): Extracted IOCs
    
    Returns:
        dict: Risk assessment
    """
    scorer = RiskScorer()
    return scorer.calculate_risk(findings, iocs)

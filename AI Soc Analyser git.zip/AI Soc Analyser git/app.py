import streamlit as st
import traceback

# Try to import, but don't crash if modules missing
try:
    from parsers.parser_router import parse_file
except ImportError:
    parse_file = None

try:
    from workflow.soc_workflow import analyze_content
except ImportError:
    analyze_content = None

try:
    from agents.investigation_agent import _get_llm, answer_soc_question
except ImportError:
    _get_llm = None
    answer_soc_question = None

st.set_page_config(
    page_title="AI SOC Copilot",
    page_icon="🛡️",
    layout="wide"
)

# ========================================
# SESSION STATE
# ========================================

if "messages" not in st.session_state:
    st.session_state.messages = []

if "analysis_result" not in st.session_state:
    st.session_state.analysis_result = None

if "uploaded_filename" not in st.session_state:
    st.session_state.uploaded_filename = None

# ========================================
# UI HEADER
# ========================================

st.title("🛡️ AI SOC Copilot")

st.markdown("""
Upload security logs, CSV files, or Excel files.

**Capabilities:**
- IOC Extraction
- Threat Detection
- Risk Scoring
- SOC Investigation Report
- AI Security Copilot Chat
""")

security_file = st.file_uploader(
    "Upload Security File",
    type=["csv", "xlsx", "xls"]
)

# ========================================
# ANALYZE BUTTON & FILE PROCESSING
# ========================================

if st.button("🔍 Analyze File"):

    if security_file is None:
        st.warning("⚠️ Please upload a file first.")
        st.stop()

    try:
        if parse_file is None:
            st.error("❌ Parser module not found. Check parsers/parser_router.py")
            st.stop()

        parsed = parse_file(security_file)

        if parsed is None:
            st.error("❌ Parser returned None. Debug: parsers/parser_router.py")
            st.stop()

        if not isinstance(parsed, dict):
            st.error(f"❌ Parser returned invalid type: {type(parsed)}")
            st.stop()

        if not parsed.get("success", False):
            error_msg = parsed.get("error", "Unknown parser error")
            st.error(f"❌ Parser error: {error_msg}")
            st.stop()

        file_text = parsed.get("content", "")
        if not file_text:
            st.error("❌ No content extracted from file")
            st.stop()

        if analyze_content is None:
            st.error("❌ Analyzer module not found. Check workflow/soc_workflow.py")
            st.stop()

        with st.spinner("🔄 Analyzing security file..."):
            result = analyze_content(file_text)

        if result is None:
            st.error("❌ Analyzer returned None. Debug: workflow/soc_workflow.py")
            st.stop()

        if not isinstance(result, dict):
            st.error(f"❌ Analyzer returned invalid type: {type(result)}")
            st.stop()

        # Reset chat history on new analysis
        st.session_state.messages = []
        st.session_state.analysis_result = result
        st.session_state.uploaded_filename = security_file.name

        st.success("✅ Analysis completed successfully!")
        st.rerun()

    except Exception as e:
        st.error(f"❌ Analysis failed: {str(e)}")
        st.error("**Traceback:**")
        st.code(traceback.format_exc())

# ========================================
# DISPLAY RESULTS (ONLY IF ANALYSIS RAN)
# ========================================

if st.session_state.analysis_result is not None:

    result = st.session_state.analysis_result

    st.divider()

    # ---- Analysis Summary Header ----
    st.subheader("📊 Analysis Summary")

    if st.session_state.uploaded_filename:
        st.write(f"**File:** `{st.session_state.uploaded_filename}`")

    # ---- Risk Assessment ----
    st.subheader("⚠️ Risk Assessment")

    try:
        risk = result.get("risk", {}) if result else {}

        if isinstance(risk, dict):
            col1, col2, col3 = st.columns(3)
            with col1:
                score = risk.get("score", "N/A")
                st.metric("Risk Score", f"{score}/100")
            with col2:
                level = risk.get("level", "Unknown")
                st.metric("Risk Level", level)
            with col3:
                evidence_count = risk.get("evidence_count", 0)
                st.metric("Evidence Items", evidence_count)

            concerns = risk.get("primary_concerns", [])
            if concerns:
                st.markdown("**Primary Concerns:**")
                for concern in concerns:
                    st.markdown(f"- {concern}")
        else:
            st.write(risk)
    except Exception as e:
        st.error(f"Error displaying risk: {str(e)}")

    # ---- Threat Findings ----
    st.subheader("🚨 Threat Findings")

    try:
        findings = result.get("findings", []) if result else []
        if findings:
            if isinstance(findings, list):
                for idx, finding in enumerate(findings, 1):
                    if isinstance(finding, dict):
                        with st.expander(
                            f"**{idx}. {finding.get('rule', 'Unknown')}** "
                            f"— Severity: `{finding.get('severity', 'MEDIUM')}`"
                        ):
                            st.markdown(f"**MITRE Tactic:** {finding.get('mitre_tactic', 'N/A')}")
                            st.markdown(f"**MITRE Technique:** {finding.get('mitre_technique', 'N/A')}")
                            st.markdown(f"**Description:** {finding.get('description', 'N/A')}")
                            if finding.get('evidence'):
                                st.markdown(f"**Evidence:** {finding.get('evidence')}")
                    else:
                        st.write(f"**{idx}.** {finding}")
            else:
                st.write(findings)
        else:
            st.success("✅ No threat findings detected.")
    except Exception as e:
        st.error(f"Error displaying findings: {str(e)}")

    # ---- Indicators of Compromise ----
    st.subheader("🔍 Indicators of Compromise (IOCs)")

    try:
        iocs = result.get("iocs", {}) if result else {}
        if iocs:
            if isinstance(iocs, dict):
                # IPs
                ipv4 = iocs.get("ips", {}).get("ipv4", [])
                ipv6 = iocs.get("ips", {}).get("ipv6", [])
                domains = iocs.get("domains", [])
                urls = iocs.get("urls", [])
                emails = iocs.get("emails", [])
                md5 = iocs.get("hashes", {}).get("md5", [])
                sha1 = iocs.get("hashes", {}).get("sha1", [])
                sha256 = iocs.get("hashes", {}).get("sha256", [])

                total = (len(ipv4) + len(ipv6) + len(domains) +
                         len(urls) + len(emails) + len(md5) + len(sha1) + len(sha256))

                if total == 0:
                    st.success("✅ No IOCs extracted.")
                else:
                    col1, col2 = st.columns(2)

                    with col1:
                        if ipv4:
                            st.markdown(f"**IPv4 Addresses ({len(ipv4)}):**")
                            for ip in ipv4[:20]:
                                st.code(ip)
                        if ipv6:
                            st.markdown(f"**IPv6 Addresses ({len(ipv6)}):**")
                            for ip in ipv6[:10]:
                                st.code(ip)
                        if emails:
                            st.markdown(f"**Email Addresses ({len(emails)}):**")
                            for email in emails[:10]:
                                st.code(email)

                    with col2:
                        if domains:
                            st.markdown(f"**Domains ({len(domains)}):**")
                            for domain in domains[:20]:
                                st.code(domain)
                        if urls:
                            st.markdown(f"**URLs ({len(urls)}):**")
                            for url in urls[:10]:
                                st.code(url)
                        if md5 or sha1 or sha256:
                            st.markdown("**File Hashes:**")
                            for h in md5[:5]:
                                st.code(f"MD5: {h}")
                            for h in sha1[:5]:
                                st.code(f"SHA1: {h}")
                            for h in sha256[:5]:
                                st.code(f"SHA256: {h}")
            else:
                st.write(iocs)
        else:
            st.success("✅ No IOCs extracted.")
    except Exception as e:
        st.error(f"Error displaying IOCs: {str(e)}")

    # ---- Investigation Report ----
    st.subheader("📋 Investigation Report")

    try:
        report = result.get("report", "") if result else ""
        if report:
            st.markdown(report)
        else:
            st.info("No investigation report available.")
    except Exception as e:
        st.error(f"Error displaying report: {str(e)}")

# ========================================
# CHAT SECTION
# ========================================

st.divider()

st.subheader("💬 SOC Copilot Chat")

if st.session_state.analysis_result is None:
    st.info("👆 Upload and analyze a file first to enable the SOC Copilot Chat.")
else:
    # Show a helpful prompt above the chat
    st.markdown(
        "Ask anything about the analysis — risk level, threats, IOCs, "
        "remediation steps, MITRE techniques, or general security questions."
    )

    # Display chat history
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    # Chat input
    user_query = st.chat_input("Ask a SOC investigation question...")

    if user_query:

        # Add user message to history
        st.session_state.messages.append({
            "role": "user",
            "content": user_query
        })

        # Display user message immediately
        with st.chat_message("user"):
            st.markdown(user_query)

        # Get response from Mistral with full context + chat history
        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                try:
                    if answer_soc_question is None:
                        response = (
                            "❌ Chat module not found. "
                            "Check agents/investigation_agent.py"
                        )
                    else:
                        response = answer_soc_question(
                            user_query,
                            st.session_state.analysis_result,
                            chat_history=st.session_state.messages[:-1]
                        )
                except Exception as e:
                    response = f"❌ Error generating response: {str(e)}"

            st.markdown(response)

        # Save assistant response to history
        st.session_state.messages.append({
            "role": "assistant",
            "content": response
        })
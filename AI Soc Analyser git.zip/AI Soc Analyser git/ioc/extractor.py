"""
IOC (Indicator of Compromise) Extractor Module
Extracts IPs, domains, URLs, emails, and hashes from text
"""

import re
import hashlib


class IOCExtractor:
    """Extract indicators of compromise from security logs and reports."""
    
    # IP address pattern (IPv4)
    IPV4_PATTERN = re.compile(
        r'\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b'
    )
    
    # IPv6 pattern
    IPV6_PATTERN = re.compile(
        r'(?:[0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}'
    )
    
    # Email pattern
    EMAIL_PATTERN = re.compile(
        r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    )
    
    # URL pattern
    URL_PATTERN = re.compile(
        r'https?://[^\s<>"{}|\\^`\[\]]+'
    )
    
    # Domain pattern (without protocol)
    DOMAIN_PATTERN = re.compile(
        r'\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}\b',
        re.IGNORECASE
    )
    
    # Hash patterns
    MD5_PATTERN = re.compile(r'\b[a-fA-F0-9]{32}\b')
    SHA1_PATTERN = re.compile(r'\b[a-fA-F0-9]{40}\b')
    SHA256_PATTERN = re.compile(r'\b[a-fA-F0-9]{64}\b')
    
    # Suspicious keywords that indicate potential threats
    SUSPICIOUS_KEYWORDS = [
        'powershell', 'cmd.exe', 'encoded', 'mimikatz', 'psexec', 'wmiexec',
        'ransomware', 'malware', 'trojan', 'backdoor', 'credential', 'dump',
        'brute force', 'attack', 'exploit', 'payload', 'injection', 'shellcode',
        'obfuscated', 'suspicious', 'anomaly', 'unauthorized', 'unauthorized access',
        'denial of service', 'ddos', 'buffer overflow', 'sql injection'
    ]
    
    def extract_all(self, text):
        """
        Extract all IOCs from text.
        
        Args:
            text (str): Text to analyze
        
        Returns:
            dict: Dictionary with all extracted IOCs
        """
        
        if not text or not isinstance(text, str):
            return self._empty_iocs()
        
        return {
            "ips": self.extract_ips(text),
            "emails": self.extract_emails(text),
            "urls": self.extract_urls(text),
            "domains": self.extract_domains(text),
            "hashes": self.extract_hashes(text),
            "suspicious_keywords": self.extract_suspicious_keywords(text)
        }
    
    def extract_ips(self, text):
        """Extract IP addresses from text."""
        ips = {
            "ipv4": list(set(self.IPV4_PATTERN.findall(text))),
            "ipv6": list(set(self.IPV6_PATTERN.findall(text)))
        }
        return ips
    
    def extract_emails(self, text):
        """Extract email addresses from text."""
        emails = list(set(self.EMAIL_PATTERN.findall(text)))
        return emails
    
    def extract_urls(self, text):
        """Extract URLs from text."""
        urls = list(set(self.URL_PATTERN.findall(text)))
        # Clean up URLs that might have trailing characters
        urls = [url.rstrip('.,;:)') for url in urls]
        return urls
    
    def extract_domains(self, text):
        """Extract domain names from text."""
        domains = list(set(self.DOMAIN_PATTERN.findall(text)))
        # Filter out common false positives
        domains = [d for d in domains if len(d) > 5 and not d.isdigit()]
        return domains
    
    def extract_hashes(self, text):
        """Extract file hashes from text."""
        hashes = {
            "md5": list(set(self.MD5_PATTERN.findall(text))),
            "sha1": list(set(self.SHA1_PATTERN.findall(text))),
            "sha256": list(set(self.SHA256_PATTERN.findall(text)))
        }
        return hashes
    
    def extract_suspicious_keywords(self, text):
        """Extract suspicious keywords from text."""
        text_lower = text.lower()
        found_keywords = []
        
        for keyword in self.SUSPICIOUS_KEYWORDS:
            if keyword in text_lower:
                found_keywords.append(keyword)
        
        return list(set(found_keywords))
    
    def _empty_iocs(self):
        """Return empty IOC structure."""
        return {
            "ips": {"ipv4": [], "ipv6": []},
            "emails": [],
            "urls": [],
            "domains": [],
            "hashes": {"md5": [], "sha1": [], "sha256": []},
            "suspicious_keywords": []
        }
    
    def ioc_count(self, iocs):
        """Count total IOCs found."""
        count = 0
        count += len(iocs.get("ips", {}).get("ipv4", []))
        count += len(iocs.get("ips", {}).get("ipv6", []))
        count += len(iocs.get("emails", []))
        count += len(iocs.get("urls", []))
        count += len(iocs.get("domains", []))
        count += len(iocs.get("hashes", {}).get("md5", []))
        count += len(iocs.get("hashes", {}).get("sha1", []))
        count += len(iocs.get("hashes", {}).get("sha256", []))
        count += len(iocs.get("suspicious_keywords", []))
        return count


def extract_iocs(text):
    """
    Convenience function to extract IOCs from text.
    
    Args:
        text (str): Text to analyze
    
    Returns:
        dict: Extracted IOCs
    """
    extractor = IOCExtractor()
    return extractor.extract_all(text)

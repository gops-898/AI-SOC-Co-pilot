def parse_log(uploaded_file):

    content = uploaded_file.read()

    return content.decode(
        "utf-8",
        errors="ignore"
    )
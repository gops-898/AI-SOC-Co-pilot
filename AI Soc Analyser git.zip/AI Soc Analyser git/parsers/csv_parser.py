import pandas as pd

def parse_csv(uploaded_file):
    try:
        uploaded_file.seek(0)
        df = pd.read_csv(uploaded_file)
        
        if df.empty:
            return {
                "success": False,
                "error": "CSV file is empty",
                "content": None,
                "rows_count": 0
            }
        
        # Convert to text
        text_lines = []
        text_lines.append("COLUMNS: " + " | ".join(df.columns))
        text_lines.append("=" * 80)
        
        for idx, row in df.iterrows():
            text_lines.append(f"ROW {idx + 1}:")
            for col, value in row.items():
                if pd.notna(value) and str(value).strip():
                    text_lines.append(f"  {col}: {str(value)}")
            text_lines.append("")
        
        text_content = "\n".join(text_lines)
        
        return {
            "success": True,
            "content": text_content,
            "error": None,
            "rows_count": len(df)
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": f"Error reading CSV: {str(e)}",
            "content": None,
            "rows_count": 0
        }
import os
from pathlib import Path
from .csv_parser import parse_csv
from .excel_parser import parse_excel

def parse_file(uploaded_file):
    try:
        if uploaded_file is None:
            return {
                "success": False,
                "error": "No file provided",
                "content": None
            }
        
        filename = uploaded_file.name
        file_extension = Path(filename).suffix.lower()
        
        if file_extension == '.csv':
            result = parse_csv(uploaded_file)
        elif file_extension in ['.xlsx', '.xls']:
            result = parse_excel(uploaded_file)
        else:
            return {
                "success": False,
                "error": f"Unsupported file type: {file_extension}",
                "content": None,
                "filename": filename
            }
        
        result['filename'] = filename
        result['file_type'] = file_extension
        
        return result
        
    except Exception as e:
        return {
            "success": False,
            "error": f"Parser error: {str(e)}",
            "content": None,
            "filename": getattr(uploaded_file, 'name', 'unknown')
        }
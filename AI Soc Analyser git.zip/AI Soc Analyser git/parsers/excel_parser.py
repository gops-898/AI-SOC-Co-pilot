import pandas as pd

def parse_excel(uploaded_file):
    try:
        uploaded_file.seek(0)
        xls = pd.ExcelFile(uploaded_file)
        sheet_names = xls.sheet_names
        
        if not sheet_names:
            return {
                "success": False,
                "error": "Excel file has no sheets",
                "content": None,
                "rows_count": 0,
                "sheets_count": 0
            }
        
        text_parts = []
        total_rows = 0
        
        for sheet_name in sheet_names:
            df = pd.read_excel(uploaded_file, sheet_name=sheet_name)
            
            if not df.empty:
                text_parts.append(f"\nSHEET: {sheet_name}\n")
                
                text_lines = []
                text_lines.append("COLUMNS: " + " | ".join(df.columns))
                text_lines.append("-" * 80)
                
                for idx, row in df.iterrows():
                    text_lines.append(f"ROW {idx + 1}:")
                    for col, value in row.items():
                        if pd.notna(value) and str(value).strip():
                            text_lines.append(f"  {col}: {str(value)}")
                    text_lines.append("")
                
                text_parts.append("\n".join(text_lines))
                total_rows += len(df)
        
        if not text_parts:
            return {
                "success": False,
                "error": "All sheets are empty",
                "content": None,
                "rows_count": 0,
                "sheets_count": len(sheet_names)
            }
        
        content = "\n".join(text_parts)
        
        return {
            "success": True,
            "content": content,
            "error": None,
            "rows_count": total_rows,
            "sheets_count": len(sheet_names)
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": f"Error reading Excel: {str(e)}",
            "content": None,
            "rows_count": 0,
            "sheets_count": 0
        }
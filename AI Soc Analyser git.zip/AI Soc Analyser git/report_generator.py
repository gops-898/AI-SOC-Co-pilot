from datetime import datetime


def generate_report(result):

    report = f"""
========================================
AI SOC COPILOT INCIDENT REPORT
========================================

Generated:
{datetime.now()}

----------------------------------------
SEVERITY
----------------------------------------

{result['severity']}

----------------------------------------
MITRE ATT&CK
----------------------------------------

{result['mitre']}

----------------------------------------
INVESTIGATION
----------------------------------------

{result['investigation']}

----------------------------------------
THREAT INTELLIGENCE
----------------------------------------

{result['intel']}

----------------------------------------
RECOMMENDATIONS
----------------------------------------

{result['recommendations']}
"""

    return report
"""
SOC Workflow Module - Minimal Working Version
"""

def analyze_content(text):
    """
    Minimal analysis function.
    
    Args:
        text (str): Parsed file content
    
    Returns:
        dict: Analysis result
    """
    
    if not text or not isinstance(text, str):
        return {
            "success": False,
            "error": "Invalid input text",
            "iocs": {},
            "findings": [],
            "risk": {"score": 0, "level": "LOW"},
            "report": "No analysis performed - invalid input"
        }
    
    try:
        # Import here to catch errors
        from ioc.extractor import extract_iocs
        from detections.detection_engine import detect_threats
        from risk.scorer import calculate_risk
        
        # Step 1: Extract IOCs
        iocs = extract_iocs(text)
        
        # Step 2: Detect threats
        findings = detect_threats(text)
        
        # Step 3: Calculate risk
        risk = calculate_risk(findings, iocs)
        
        # Step 4: Generate report
        report = _generate_report(iocs, findings, risk)
        
        return {
            "success": True,
            "error": None,
            "iocs": iocs,
            "findings": findings,
            "risk": risk,
            "report": report
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": f"Analysis failed: {str(e)}",
            "iocs": {},
            "findings": [],
            "risk": {"score": 0, "level": "LOW"},
            "report": f"Analysis failed: {str(e)}"
        }


def _generate_report(iocs, findings, risk):
    """Generate a simple text report."""
    
    lines = []
    lines.append("=" * 80)
    lines.append("SECURITY ANALYSIS REPORT")
    lines.append("=" * 80)
    lines.append("")
    
    # Risk
    lines.append(f"RISK LEVEL: {risk.get('level', 'UNKNOWN')}")
    lines.append(f"RISK SCORE: {risk.get('score', 0)}/100")
    lines.append("")
    
    # Findings
    if findings:
        lines.append(f"THREATS DETECTED: {len(findings)}")
        lines.append("")
        for finding in findings:
            lines.append(f"  • {finding.get('rule', 'Unknown')}")
            lines.append(f"    Severity: {finding.get('severity', 'MEDIUM')}")
            lines.append("")
    else:
        lines.append("THREATS DETECTED: None")
        lines.append("")
    
    # IOCs
    ioc_count = _count_iocs(iocs)
    if ioc_count > 0:
        lines.append(f"INDICATORS OF COMPROMISE: {ioc_count} found")
        lines.append("")
        
        ipv4 = iocs.get('ips', {}).get('ipv4', [])
        if ipv4:
            lines.append(f"  IPv4 Addresses: {', '.join(ipv4[:5])}")
            if len(ipv4) > 5:
                lines.append(f"    ... and {len(ipv4)-5} more")
        
        domains = iocs.get('domains', [])
        if domains:
            lines.append(f"  Domains: {', '.join(domains[:5])}")
            if len(domains) > 5:
                lines.append(f"    ... and {len(domains)-5} more")
    else:
        lines.append("INDICATORS OF COMPROMISE: None")
    
    lines.append("")
    lines.append("=" * 80)
    
    return "\n".join(lines)


def _count_iocs(iocs):
    """Count total IOCs."""
    count = 0
    count += len(iocs.get("ips", {}).get("ipv4", []))
    count += len(iocs.get("ips", {}).get("ipv6", []))
    count += len(iocs.get("emails", []))
    count += len(iocs.get("urls", []))
    count += len(iocs.get("domains", []))
    count += len(iocs.get("hashes", {}).get("md5", []))
    count += len(iocs.get("hashes", {}).get("sha1", []))
    count += len(iocs.get("hashes", {}).get("sha256", []))
    return count

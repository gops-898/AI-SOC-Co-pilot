import os

try:
    from chromadb import PersistentClient  # type: ignore[import]
except ImportError as exc:
    raise ImportError(
        "chromadb is not installed. Install it with `pip install chromadb`."
    ) from exc

DB_PATH = "vector_db"

client = PersistentClient(path=DB_PATH)

collection = client.get_or_create_collection(
    name="soc_knowledge_base"
)
import os
import shutil
import importlib

from langchain_text_splitters import RecursiveCharacterTextSplitter

# --------------------------------------------------
# ChromaDB Import Check
# --------------------------------------------------

try:
    chromadb = importlib.import_module("chromadb")
    PersistentClient = chromadb.PersistentClient

except ImportError as e:
    raise ImportError(
        "chromadb is not installed.\n"
        "Install using:\n"
        "pip install chromadb"
    ) from e


# --------------------------------------------------
# Paths
# --------------------------------------------------

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

VECTOR_DB_PATH = os.path.join(
    BASE_DIR,
    "vector_db"
)

KNOWLEDGE_PATH = os.path.join(
    BASE_DIR,
    "knowledge_base"
)

# --------------------------------------------------
# Validate Knowledge Base
# --------------------------------------------------

if not os.path.exists(KNOWLEDGE_PATH):

    os.makedirs(
        KNOWLEDGE_PATH,
        exist_ok=True
    )

    raise FileNotFoundError(
        f"Knowledge directory '{KNOWLEDGE_PATH}' was missing.\n"
        "Folder created. Add .md files and rerun."
    )


markdown_files = [

    file

    for file in os.listdir(KNOWLEDGE_PATH)

    if file.endswith(".md")
]

if not markdown_files:

    raise FileNotFoundError(
        f"No markdown files found in '{KNOWLEDGE_PATH}'.\n"
        "Add .md files and rerun."
    )

# --------------------------------------------------
# Optional Reset
# --------------------------------------------------

RESET_DB = True

if RESET_DB and os.path.exists(VECTOR_DB_PATH):

    shutil.rmtree(
        VECTOR_DB_PATH
    )

# --------------------------------------------------
# Create ChromaDB
# --------------------------------------------------

client = PersistentClient(
    path=VECTOR_DB_PATH
)

collection = client.get_or_create_collection(
    name="soc_knowledge_base"
)

# --------------------------------------------------
# Chunking Strategy
# --------------------------------------------------

splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=50,
    separators=[
        "\n\n",
        "\n",
        ". ",
        " "
    ]
)

documents = []
ids = []

counter = 0

# --------------------------------------------------
# Process Documents
# --------------------------------------------------

for file in markdown_files:

    file_path = os.path.join(
        KNOWLEDGE_PATH,
        file
    )

    print(
        f"Processing: {file}"
    )

    with open(
        file_path,
        "r",
        encoding="utf-8"
    ) as f:

        text = f.read()

    chunks = splitter.split_text(
        text
    )

    for chunk in chunks:

        documents.append(
            chunk
        )

        ids.append(
            f"doc_{counter}"
        )

        counter += 1

# --------------------------------------------------
# Store in Chroma
# --------------------------------------------------

collection.add(
    documents=documents,
    ids=ids
)

# --------------------------------------------------
# Summary
# --------------------------------------------------

print(
    "\n=============================="
)

print(
    f"Documents Loaded: {len(markdown_files)}"
)

print(
    f"Chunks Created : {len(documents)}"
)

print(
    "Vector DB Ready"
)

print(
    "=============================="
)
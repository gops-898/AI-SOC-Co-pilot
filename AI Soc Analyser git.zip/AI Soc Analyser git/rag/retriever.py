from chromadb import PersistentClient

client = PersistentClient(
    path="vector_db"
)

collection = client.get_or_create_collection(
    name="soc_knowledge_base"
)


def retrieve_context(
    query,
    top_k=3
):

    results = collection.query(
        query_texts=[query],
        n_results=top_k
    )

    documents = results["documents"][0]

    return "\n\n".join(documents)
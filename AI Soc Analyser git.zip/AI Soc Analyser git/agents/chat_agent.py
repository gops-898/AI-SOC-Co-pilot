from langchain_mistralai import ChatMistralAI
from dotenv import load_dotenv

load_dotenv()

llm = ChatMistralAI(
    model="ministral-8b-latest",
    temperature=0
)


def ask_soc_copilot(
    question,
    analysis
):

    prompt = f"""
SOC Investigation:

{analysis}

Question:

{question}

Answer as a senior SOC analyst.
"""

    return llm.invoke(prompt).content
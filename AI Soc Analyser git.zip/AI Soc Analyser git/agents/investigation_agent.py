"""
Investigation Agent Module
Evidence-based SOC analysis with Mistral-powered chat
"""

from langchain_mistralai import ChatMistralAI
from dotenv import load_dotenv
import os

load_dotenv()


# ========================================
# LLM SETUP
# ========================================

def _get_llm():
    """Initialize Mistral LLM."""
    try:
        llm = ChatMistralAI(
            model="ministral-8b-latest",
            temperature=0.2,
            max_tokens=1500
        )
        return llm
    except Exception as e:
        print(f"Warning: LLM not available: {e}")
        return None


# ========================================
# EVIDENCE BUILDER
# ========================================

def _build_full_evidence(iocs, findings, risk):
    """
    Build a complete, detailed evidence summary string
    to pass as context to the LLM.
    """
    lines = []

    # --- Risk ---
    lines.append("=== RISK ASSESSMENT ===")
    lines.append(f"Risk Level : {risk.get('level', 'UNKNOWN')}")
    lines.append(f"Risk Score : {risk.get('score', 0)} / 100")
    lines.append(f"Evidence Items : {risk.get('evidence_count', 0)}")
    concerns = risk.get("primary_concerns", [])
    if concerns:
        lines.append("Primary Concerns:")
        for c in concerns:
            lines.append(f"  - {c}")
    else:
        lines.append("Primary Concerns: None identified")

    lines.append("")

    # --- Threats ---
    lines.append("=== THREAT FINDINGS ===")
    if findings:
        lines.append(f"Total Threats Detected: {len(findings)}")
        for i, f in enumerate(findings, 1):
            lines.append(f"\n[Threat {i}]")
            lines.append(f"  Rule        : {f.get('rule', 'Unknown')}")
            lines.append(f"  Severity    : {f.get('severity', 'MEDIUM')}")
            lines.append(f"  MITRE Tactic: {f.get('mitre_tactic', 'N/A')}")
            lines.append(f"  MITRE Tech  : {f.get('mitre_technique', 'N/A')}")
            lines.append(f"  Description : {f.get('description', 'N/A')}")
            lines.append(f"  Evidence    : {f.get('evidence', 'N/A')}")
    else:
        lines.append("No threats detected.")

    lines.append("")

    # --- IOCs ---
    lines.append("=== INDICATORS OF COMPROMISE (IOCs) ===")
    ioc_count = _count_iocs(iocs)
    if ioc_count > 0:
        lines.append(f"Total IOCs Found: {ioc_count}")

        ipv4 = iocs.get("ips", {}).get("ipv4", [])
        if ipv4:
            lines.append(f"\nIPv4 Addresses ({len(ipv4)}):")
            for ip in ipv4[:20]:
                lines.append(f"  - {ip}")

        ipv6 = iocs.get("ips", {}).get("ipv6", [])
        if ipv6:
            lines.append(f"\nIPv6 Addresses ({len(ipv6)}):")
            for ip in ipv6[:10]:
                lines.append(f"  - {ip}")

        domains = iocs.get("domains", [])
        if domains:
            lines.append(f"\nDomains ({len(domains)}):")
            for d in domains[:20]:
                lines.append(f"  - {d}")

        urls = iocs.get("urls", [])
        if urls:
            lines.append(f"\nURLs ({len(urls)}):")
            for u in urls[:10]:
                lines.append(f"  - {u}")

        emails = iocs.get("emails", [])
        if emails:
            lines.append(f"\nEmail Addresses ({len(emails)}):")
            for e in emails[:10]:
                lines.append(f"  - {e}")

        md5 = iocs.get("hashes", {}).get("md5", [])
        sha1 = iocs.get("hashes", {}).get("sha1", [])
        sha256 = iocs.get("hashes", {}).get("sha256", [])
        if md5 or sha1 or sha256:
            lines.append(f"\nFile Hashes:")
            for h in md5[:5]:
                lines.append(f"  MD5    : {h}")
            for h in sha1[:5]:
                lines.append(f"  SHA1   : {h}")
            for h in sha256[:5]:
                lines.append(f"  SHA256 : {h}")
    else:
        lines.append("No IOCs detected.")

    return "\n".join(lines)


# ========================================
# INVESTIGATION REPORT GENERATOR
# ========================================

def generate_investigation_report(text, iocs, findings, risk):
    """
    Generate an evidence-based investigation report using Mistral.
    Never invents threats — only explains detected evidence.
    """
    try:
        llm = _get_llm()
        evidence = _build_full_evidence(iocs, findings, risk)

        if llm is not None:
            prompt = f"""You are a Senior SOC Analyst writing an official investigation report.

STRICT RULES:
- Base your report ONLY on the evidence provided below
- Do NOT invent threats, attacks, or IOCs that are not in the evidence
- If risk is LOW and no threats found, clearly state the environment appears clean
- Be professional, concise, and factual

DETECTED EVIDENCE:
{evidence}

Write a structured investigation report with:
1. Executive Summary
2. Risk Assessment
3. Threat Analysis (only if threats exist)
4. IOC Summary (only if IOCs exist)
5. Recommended Actions
6. Conclusion
"""
            response = llm.invoke(prompt)
            return response.content
        else:
            return _generate_text_report(iocs, findings, risk)

    except Exception as e:
        return _generate_text_report(iocs, findings, risk)


# ========================================
# SOC COPILOT CHAT  ← MAIN FIX IS HERE
# ========================================

def answer_soc_question(user_query, analysis_result, chat_history=None):
    """
    Answer any SOC analyst question using Mistral with full analysis context.
    No more keyword matching — every question goes through the LLM.

    Args:
        user_query (str): The analyst's question
        analysis_result (dict): Full analysis result from workflow
        chat_history (list): Optional list of previous messages [{"role": ..., "content": ...}]

    Returns:
        str: Mistral's answer grounded in the analysis evidence
    """

    if not analysis_result:
        return (
            "⚠️ No analysis has been performed yet. "
            "Please upload a security file and click **Analyze** first."
        )

    findings = analysis_result.get("findings", [])
    iocs     = analysis_result.get("iocs", {})
    risk     = analysis_result.get("risk", {})

    # Build full evidence context
    evidence = _build_full_evidence(iocs, findings, risk)

    # Try LLM first — this handles ALL questions intelligently
    llm = _get_llm()
    if llm:
        try:
            # Build conversation messages
            messages = []

            # System context — injected as first user turn for Mistral compatibility
            system_context = f"""You are an expert Senior SOC Analyst and cybersecurity advisor. 
You have access to the following security analysis results from a recently analyzed file.

ANALYSIS EVIDENCE:
{evidence}

YOUR RULES:
- Answer ANY security question the analyst asks, drawing on this evidence
- You may also use your general cybersecurity knowledge to explain concepts, 
  suggest investigation steps, explain MITRE techniques, or advise on remediation
- Always ground your answers in the actual evidence above when relevant
- If the question is about something not in the evidence, say so clearly but still help
- Be conversational, thorough, and professional
- Never repeat the same canned response — tailor every answer to the specific question
- Format responses clearly with bullet points or sections when helpful
"""
            messages.append({"role": "user", "content": system_context})
            messages.append({"role": "assistant", "content": 
                "Understood. I have reviewed the analysis results and I'm ready to answer "
                "your security questions based on this evidence."
            })

            # Add chat history for context (last 6 turns to avoid token overflow)
            if chat_history:
                for turn in chat_history[-6:]:
                    role = turn.get("role", "user")
                    content = turn.get("content", "")
                    if role in ("user", "assistant") and content:
                        messages.append({"role": role, "content": content})

            # Add current question
            messages.append({"role": "user", "content": user_query})

            response = llm.invoke(messages)
            return response.content

        except Exception as e:
            # If LLM fails, fall back to structured answer
            return _fallback_answer(user_query, findings, iocs, risk, error=str(e))

    # No LLM available — structured fallback
    return _fallback_answer(user_query, findings, iocs, risk)


# ========================================
# STRUCTURED FALLBACK (no LLM)
# ========================================

def _fallback_answer(user_query, findings, iocs, risk, error=None):
    """
    Keyword-based fallback when Mistral is unavailable.
    Much more detailed than before.
    """
    q = user_query.lower()
    ioc_count = _count_iocs(iocs)

    # Risk
    if any(w in q for w in ["risk", "score", "level", "severity", "danger"]):
        concerns = risk.get("primary_concerns", [])
        concern_text = "\n".join([f"  • {c}" for c in concerns]) if concerns else "  • No specific concerns identified"
        return (
            f"**Risk Assessment**\n\n"
            f"- **Risk Level:** {risk.get('level', 'UNKNOWN')}\n"
            f"- **Risk Score:** {risk.get('score', 0)} / 100\n"
            f"- **Evidence Items Analyzed:** {risk.get('evidence_count', 0)}\n\n"
            f"**Primary Concerns:**\n{concern_text}"
        )

    # Threats
    if any(w in q for w in ["threat", "attack", "detect", "malware", "exploit", "suspicious"]):
        if not findings:
            return "✅ **No threats detected** in this file. The content appears clean based on rule-based analysis."
        lines = [f"**{len(findings)} Threat(s) Detected:**\n"]
        for i, f in enumerate(findings, 1):
            lines.append(f"**{i}. {f.get('rule', 'Unknown')}**")
            lines.append(f"   - Severity: `{f.get('severity', 'MEDIUM')}`")
            lines.append(f"   - MITRE Tactic: `{f.get('mitre_tactic', 'N/A')}`")
            lines.append(f"   - MITRE Technique: `{f.get('mitre_technique', 'N/A')}`")
            lines.append(f"   - Description: {f.get('description', 'N/A')}\n")
        return "\n".join(lines)

    # IOCs
    if any(w in q for w in ["ioc", "indicator", "ip", "domain", "url", "hash", "email", "address"]):
        if ioc_count == 0:
            return "✅ **No indicators of compromise (IOCs)** were found in this file."
        lines = [f"**{ioc_count} IOC(s) Found:**\n"]
        ipv4 = iocs.get("ips", {}).get("ipv4", [])
        if ipv4:
            lines.append(f"**IP Addresses ({len(ipv4)}):** {', '.join(ipv4[:10])}")
        domains = iocs.get("domains", [])
        if domains:
            lines.append(f"**Domains ({len(domains)}):** {', '.join(domains[:10])}")
        urls = iocs.get("urls", [])
        if urls:
            lines.append(f"**URLs ({len(urls)}):** {', '.join(urls[:5])}")
        emails = iocs.get("emails", [])
        if emails:
            lines.append(f"**Emails ({len(emails)}):** {', '.join(emails[:10])}")
        return "\n".join(lines)

    # Remediation / action
    if any(w in q for w in ["remediat", "fix", "action", "recommend", "mitigat", "respond", "next step"]):
        if not findings:
            return (
                "✅ No threats were detected, so no immediate remediation is required.\n\n"
                "**General recommendations:**\n"
                "- Continue monitoring logs regularly\n"
                "- Ensure endpoint detection tools are up to date\n"
                "- Review any flagged IOCs against threat intelligence feeds"
            )
        lines = ["**Recommended Remediation Steps:**\n"]
        for f in findings[:5]:
            lines.append(f"- **{f.get('rule', 'Finding')}**: Investigate host activity, "
                         f"isolate if confirmed malicious, review `{f.get('mitre_technique', 'N/A')}`")
        return "\n".join(lines)

    # Summary / overview
    if any(w in q for w in ["summary", "overview", "overall", "what", "tell me", "explain", "harm"]):
        return (
            f"**Analysis Summary**\n\n"
            f"- **Risk Level:** {risk.get('level', 'UNKNOWN')} ({risk.get('score', 0)}/100)\n"
            f"- **Threats Detected:** {len(findings)}\n"
            f"- **IOCs Found:** {ioc_count}\n"
            f"- **Evidence Items:** {risk.get('evidence_count', 0)}\n\n"
            + ("⚠️ Threats were found — review the Threat Findings section for details." 
               if findings else "✅ No threats or malicious indicators were detected in this file.")
        )

    # Default
    err_note = f"\n\n_(LLM unavailable: {error})_" if error else ""
    return (
        f"**Current Analysis State:**\n\n"
        f"- Risk: **{risk.get('level', 'UNKNOWN')}** ({risk.get('score', 0)}/100)\n"
        f"- Threats: **{len(findings)}**\n"
        f"- IOCs: **{ioc_count}**\n\n"
        f"You can ask me about: risk level, detected threats, IOCs, remediation steps, "
        f"MITRE techniques, or a general summary."
        f"{err_note}"
    )


# ========================================
# HELPERS
# ========================================

def _count_iocs(iocs):
    count = 0
    count += len(iocs.get("ips", {}).get("ipv4", []))
    count += len(iocs.get("ips", {}).get("ipv6", []))
    count += len(iocs.get("emails", []))
    count += len(iocs.get("urls", []))
    count += len(iocs.get("domains", []))
    count += len(iocs.get("hashes", {}).get("md5", []))
    count += len(iocs.get("hashes", {}).get("sha1", []))
    count += len(iocs.get("hashes", {}).get("sha256", []))
    return count


def _generate_text_report(iocs, findings, risk):
    """Plain-text fallback report."""
    evidence = _build_full_evidence(iocs, findings, risk)
    lines = [
        "=" * 60,
        "SECURITY ANALYSIS REPORT",
        "=" * 60,
        "",
        evidence,
        "",
        "CONCLUSION:",
    ]
    if findings:
        lines.append(f"  {len(findings)} threat(s) require immediate investigation.")
    else:
        lines.append("  No significant security concerns detected.")
    lines.append("=" * 60)
    return "\n".join(lines)
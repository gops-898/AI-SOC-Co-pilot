from rag.retriever import retrieve_context


def threat_intel_lookup(
    alert_text
):

    context = retrieve_context(
        alert_text,
        top_k=3
    )

    return context
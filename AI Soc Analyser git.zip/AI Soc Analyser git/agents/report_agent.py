from langchain_mistralai import ChatMistralAI
from dotenv import load_dotenv
import os

load_dotenv()

llm = ChatMistralAI(
    model="ministral-8b-latest",
    temperature=0
)

def generate_soc_report(results):

    prompt = f"""
You are a SOC analyst.

IOCs:
{results['iocs']}

Detections:
{results['detections']}

Threat Intelligence:
{results['context']}

Generate:

1. Incident Summary
2. MITRE ATT&CK Mapping
3. Severity Assessment
4. Investigation Steps
5. Remediation
"""

    response = llm.invoke(prompt)

    return response.content
from langchain_mistralai import ChatMistralAI
from dotenv import load_dotenv
import os

load_dotenv()

llm = ChatMistralAI(
    model="ministral-8b-latest",
    temperature=0
)


def generate_investigation(
    findings,
    iocs,
    risk
):

    prompt = f"""
You are a SOC analyst.

Findings:
{findings}

IOCs:
{iocs}

Risk:
{risk}

Generate:

1. Summary
2. Threat Assessment
3. Investigation Steps
4. Containment Actions
5. Remediation
"""

    return llm.invoke(prompt).content
import importlib.util
import os

if importlib.util.find_spec("dotenv") is not None:
    load_dotenv = importlib.import_module("dotenv").load_dotenv
else:
    load_dotenv = lambda: None

try:
    from langchain_mistralai import ChatMistralAI  # type: ignore
except Exception:
    try:
        from mistralai import ChatMistralAI  # type: ignore
    except Exception:
        ChatMistralAI = None  # type: ignore

load_dotenv()

if ChatMistralAI is not None:
    llm = ChatMistralAI(
        model="mistral-large-latest",
        temperature=0.2,
        api_key=os.getenv("MISTRAL_API_KEY"),
    )
else:
    llm = None

def generate_recommendations(
    alert_text,
    severity
):

    prompt = f"""
You are a senior SOC analyst.

Alert:

{alert_text}

Severity:

{severity}

Generate:

1. Containment Actions
2. Investigation Steps
3. Remediation Steps

Keep response concise.
"""

    if llm is None:
        raise RuntimeError("No ChatMistralAI available. Install langchain_mistralai or mistralai and set MISTRAL_API_KEY.")

    response = llm.invoke(prompt)
    return getattr(response, "content", response)
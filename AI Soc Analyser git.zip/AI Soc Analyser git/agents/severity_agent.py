def classify_severity(
    alert_text
):

    text = alert_text.lower()

    if "exfiltration" in text:
        return "Critical"

    if "powershell" in text:
        return "High"

    if "brute force" in text:
        return "Medium"

    return "Low"
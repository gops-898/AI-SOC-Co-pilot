def map_mitre(alert_text):

    text = alert_text.lower()

    if "powershell" in text:
        return "T1059.001 - PowerShell"

    if "brute force" in text:
        return "T1110 - Brute Force"

    if "exfiltration" in text:
        return "T1041 - Exfiltration"

    return "Unknown Technique"
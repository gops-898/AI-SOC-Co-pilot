# MITRE ATT&CK

T1059.001 - PowerShell

Adversaries may abuse PowerShell commands and scripts for execution.

Indicators:

- Encoded PowerShell
- Download Cradle
- Remote PowerShell

Mitigations:

- Restrict PowerShell
- Enable Logging
- Monitor Suspicious Commands
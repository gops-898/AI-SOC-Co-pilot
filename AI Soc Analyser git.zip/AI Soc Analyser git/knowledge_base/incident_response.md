# Incident Response

Containment

- Isolate affected systems
- Disable compromised accounts

Investigation

- Review logs
- Gather forensic evidence

Recovery

- Restore systems
- Validate integrity

Lessons Learned

- Improve monitoring
- Update detections
# Threat Intelligence

PowerShell attacks frequently leverage encoded commands.

Brute force attacks typically involve repeated failed logins.

Data exfiltration often includes large outbound transfers to external destinations.

Threat actors may use PowerShell for malware delivery and persistence.
print("Loading workflow...")

from agents.investigation_agent import investigate_alert
print("investigation_agent loaded")

from agents.mitre_agent import map_mitre
print("mitre_agent loaded")

from agents.severity_agent import classify_severity
print("severity_agent loaded")

from agents.threat_intel_agent import threat_intel_lookup
print("threat_intel_agent loaded")

from agents.recommendation_agent import generate_recommendations
print("recommendation_agent loaded")

from typing import TypedDict

from langgraph.graph import StateGraph

from agents.investigation_agent import investigate_alert
from agents.mitre_agent import map_mitre
from agents.severity_agent import classify_severity
from agents.threat_intel_agent import threat_intel_lookup
from agents.recommendation_agent import generate_recommendations


class AlertState(TypedDict):
    alert: str
    investigation: str
    mitre: str
    severity: str
    intel: str
    recommendations: str


def investigation_node(state):
    state["investigation"] = investigate_alert(
        state["alert"]
    )
    return state


def mitre_node(state):
    state["mitre"] = map_mitre(
        state["alert"]
    )
    return state


def severity_node(state):
    state["severity"] = classify_severity(
        state["alert"]
    )
    return state


def intel_node(state):
    state["intel"] = threat_intel_lookup(
        state["alert"]
    )
    return state


def recommendation_node(state):
    state["recommendations"] = (
        generate_recommendations(
            state["alert"],
            state["severity"]
        )
    )
    return state


graph = StateGraph(AlertState)

graph.add_node(
    "investigation",
    investigation_node
)

graph.add_node(
    "mitre",
    mitre_node
)

graph.add_node(
    "severity",
    severity_node
)

graph.add_node(
    "intel",
    intel_node
)

graph.add_node(
    "recommendation",
    recommendation_node
)

graph.set_entry_point(
    "investigation"
)

graph.add_edge(
    "investigation",
    "mitre"
)

graph.add_edge(
    "mitre",
    "severity"
)

graph.add_edge(
    "severity",
    "intel"
)

graph.add_edge(
    "intel",
    "recommendation"
)

graph.set_finish_point(
    "recommendation"
)

workflow = graph.compile()
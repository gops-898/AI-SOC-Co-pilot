from workflow_langgraph import workflow, analyze_content

def analyze_file(uploaded_file):

    raw = uploaded_file.read()

    try:

        text = raw.decode(
            "utf-8",
            errors="ignore"
        )

    except:

        text = str(raw)

    return analyze_content(
        text
    )
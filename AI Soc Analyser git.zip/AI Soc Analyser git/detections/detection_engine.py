"""
Detection Engine Module
Rule-based threat detection for security logs and artifacts
"""

import re


class DetectionEngine:
    """Rule-based threat detection engine."""
    
    # Detection rules: (rule_name, pattern, severity, mitre_tactic)
    DETECTION_RULES = [
        # Command Execution
        ("PowerShell Encoded Command", r'(?:powershell|pwsh).*?(?:\-enc|\-encodedcommand)', "HIGH", "execution"),
        ("Suspicious Cmd Execution", r'cmd\.exe.*?(?:/c|/k|&|&&|\|)', "MEDIUM", "execution"),
        
        # Credential Access
        ("Mimikatz Usage", r'(?:mimikatz|sekurlsa|logonpasswords)', "CRITICAL", "credential_access"),
        ("Credential Dumping", r'(?:lsass|credential|password.*dump|dumping)', "HIGH", "credential_access"),
        ("NTLM Hash Extraction", r'(?:ntlm|hash.*extract|sam.*dump)', "HIGH", "credential_access"),
        
        # Lateral Movement
        ("Psexec Usage", r'psexec|impacket.*psexec', "HIGH", "lateral_movement"),
        ("WMI Remote Execution", r'(?:wmiexec|wmi.*execute|win32_process)', "HIGH", "lateral_movement"),
        ("SMB Exploitation", r'(?:smb.*exploit|eternal.*blue|ms17.010)', "CRITICAL", "lateral_movement"),
        
        # Defense Evasion
        ("Obfuscated Code", r'(?:base64|obfuscate|obfuscated|encoded)', "MEDIUM", "defense_evasion"),
        ("Disable Antivirus", r'(?:disable.*antivirus|av.*disable|windows.*defender.*disable)', "HIGH", "defense_evasion"),
        
        # Persistence
        ("Registry Modification", r'reg\.exe.*(?:add|import).*(?:run|runonce)', "MEDIUM", "persistence"),
        ("Scheduled Task Creation", r'schtasks.*?/create|at\.exe', "MEDIUM", "persistence"),
        
        # Impact
        ("Ransomware Indicators", r'(?:encrypt|ransom|cryptor|.locked|.encrypted)', "CRITICAL", "impact"),
        ("File Deletion", r'(?:del /s|deltree|format|cipher.*\/w)', "HIGH", "impact"),
        
        # Exploitation
        ("Buffer Overflow", r'(?:buffer.*overflow|heap.*overflow|stack.*overflow)', "HIGH", "exploitation"),
        ("SQL Injection Attempt", r"(?:union.*select|exec.*xp_|'.*or.*'.*=)", "HIGH", "exploitation"),
        
        # Exfiltration
        ("Data Exfiltration", r'(?:exfil|upload.*data|send.*data|http.*post.*file)', "HIGH", "exfiltration"),
        ("FTP Transfer", r'ftp://|ftp.*upload|ftp.*send', "MEDIUM", "exfiltration"),
    ]
    
    def detect_threats(self, text):
        """
        Run all detection rules against text.
        
        Args:
            text (str): Text to analyze
        
        Returns:
            list: List of detected threats with details
        """
        
        if not text or not isinstance(text, str):
            return []
        
        findings = []
        text_lower = text.lower()
        
        for rule_name, pattern, severity, tactic in self.DETECTION_RULES:
            try:
                if re.search(pattern, text_lower, re.IGNORECASE):
                    findings.append({
                        "rule": rule_name,
                        "severity": severity,
                        "mitre_tactic": tactic,
                        "description": f"Detection rule '{rule_name}' matched in log data",
                        "evidence": True  # This is actual evidence, not hallucination
                    })
            except re.error:
                # Skip invalid regex patterns
                continue
        
        return findings
    
    def get_findings_summary(self, findings):
        """
        Summarize findings by severity.
        
        Args:
            findings (list): List of findings
        
        Returns:
            dict: Summary of findings
        """
        
        summary = {
            "CRITICAL": [],
            "HIGH": [],
            "MEDIUM": [],
            "LOW": []
        }
        
        for finding in findings:
            severity = finding.get("severity", "MEDIUM")
            summary[severity].append(finding)
        
        return summary


def detect_threats(text):
    """
    Convenience function to detect threats in text.
    
    Args:
        text (str): Text to analyze
    
    Returns:
        list: Detected threats
    """
    engine = DetectionEngine()
    return engine.detect_threats(text)
